import React from 'react';
import { Link, NavLink } from 'react-router-dom';

function Navbar() {
  return (
    <nav className='bg-black'>
      <div className="relative z-10 flex justify-between items-center px-12 py-6 text-white">
          <h1 className="text-3xl font-bold text-orange-500">Flyaway</h1>

          <ul className="flex gap-8 text-sm font-medium space-x-4 ">
            <NavLink to="/"  className={({ isActive }) =>
              isActive
                ? "text-orange-500 font-bold border-b-2 border-orange-500"
                : "text-white hover:text-orange-400"}>Home</NavLink>
            <NavLink to="/destinations" className={({ isActive }) =>
              isActive
                ? "text-orange-500 font-bold border-b-2 border-orange-500"
                : "text-white hover:text-orange-400"}>Destinations</NavLink>
            <NavLink to="/about" className={({ isActive }) =>
              isActive
                ? "text-orange-500 font-bold border-b-2 border-orange-500"
                : "text-white hover:text-orange-400"}>About</NavLink>
            <NavLink to="/contact" className={({ isActive }) =>
              isActive
                ? "text-orange-500 font-bold border-b-2 border-orange-500"
                : "text-white hover:text-orange-400"}>Contact</NavLink>
          </ul>

          <div className="text-xl">👤</div>
        </div>
    </nav>
  );
}

export default Navbar;
