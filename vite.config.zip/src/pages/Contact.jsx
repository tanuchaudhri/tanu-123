import React from "react";
import heroBg from "../assets/hero.jpg";

function Contact() {
  return (
    <div className="w-full bg-white">
      {/* ================= HERO ================= */}
      <div
        className="relative h-[60vh] bg-cover bg-center"
        style={{ backgroundImage: `url(${heroBg})` }}
      >
        <div className="absolute inset-0 bg-black/40"></div>

        <div className="relative z-10 flex items-center justify-center h-full">
          <h1 className="text-white text-5xl font-semibold">Contact</h1>
        </div>
      </div>

      {/* ================= CONTACT SECTION ================= */}
      <div className="max-w-6xl mx-auto py-20 px-4 grid md:grid-cols-2 gap-16 items-start">
        {/* LEFT FORM */}
        <div>
          <h2 className="text-2xl font-semibold mb-8">Get in Touch</h2>

          <div className="grid grid-cols-2 gap-6 mb-6">
            <div>
              <label className="text-sm">First Name</label>
              <input
                type="text"
                placeholder="ex. Jhon"
                className="w-full border rounded-md px-4 py-2 outline-none"
              />
            </div>

            <div>
              <label className="text-sm">Last Name</label>
              <input
                type="text"
                placeholder="ex. Jhon"
                className="w-full border rounded-md px-4 py-2 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6 mb-6">
            <div>
              <label className="text-sm">Email</label>
              <input
                type="email"
                placeholder="example@gmail.com"
                className="w-full border rounded-md px-4 py-2 outline-none"
              />
            </div>

            <div>
              <label className="text-sm">Phone</label>
              <input
                type="text"
                placeholder="+620123456789"
                className="w-full border rounded-md px-4 py-2 outline-none"
              />
            </div>
          </div>

          <div className="mb-6">
            <label className="text-sm">Subject</label>
            <input
              type="text"
              placeholder="Enter here"
              className="w-full border rounded-md px-4 py-2 outline-none"
            />
          </div>

          <div className="mb-8">
            <label className="text-sm">Messages</label>
            <textarea
              placeholder="Enter here"
              className="w-full border rounded-md px-4 py-4 outline-none h-32 resize-none"
            ></textarea>
          </div>

          <button className="bg-blue-200 text-black px-10 py-3 rounded-md">
            Submit
          </button>
        </div>

        {/* RIGHT IMAGE */}
        <div>
          <img
            src="https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?q=80&w=1200"
            alt="Hot Air Balloon"
            className="rounded-xl w-full h-[520px] object-cover"
          />
        </div>
      </div>

      {/* ================= INFO BOXES ================= */}
      <div className="max-w-6xl mx-auto pb-16 px-4 grid md:grid-cols-3 gap-6 text-center">
        <div className="bg-[#f4fbff] py-6 rounded-md">
          <p className="text-sm mb-1">Flyaway</p>
        </div>

        <div className="bg-[#f4fbff] py-6 rounded-md">
          <p className="text-sm mb-1">089523456789</p>
        </div>

        <div className="bg-[#f4fbff] py-6 rounded-md">
          <p className="text-sm mb-1">example@gmail.com</p>
        </div>
      </div>
    </div>
  );
}

export default Contact;
