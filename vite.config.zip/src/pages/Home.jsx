import React from "react";
import heroBg from "../assets/hero.jpg";

function Home() {
  return (
    <div className="w-full bg-[#f8f9fc]">

      {/* ================= NAVBAR + HERO ================= */}
      <div
        className="relative h-screen bg-cover bg-center"
        style={{ backgroundImage: `url(${heroBg})` }}
      >
        <div className="absolute inset-0 bg-black/50"></div>

        {/* Hero Content */}
        <div className="relative z-10 flex flex-col items-center justify-center h-full text-white text-center">
          <h1 className="text-5xl font-bold mb-4">
            Explore The World With Us
          </h1>
          <p className="text-sm mb-8 opacity-80">
            Discover 456 Places Worldwide
          </p>

          <div className="bg-white rounded-full flex items-center px-6 py-2 w-[480px] shadow-md">
            <input
              type="text"
              placeholder="Search Your Destination"
              className="flex-1 outline-none text-black text-sm"
            />
            <span className="text-orange-500 text-xl">🔍</span>
          </div>
        </div>
      </div>

      {/* ================= TOP COUNTRIES ================= */}
      <div className="max-w-7xl mx-auto px-10 py-16">
        <h2 className="text-lg font-semibold mb-6">
          Top Countries For Your Journey
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { name: "France", img: "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba" },
            { name: "England", img: "https://images.unsplash.com/photo-1505761671935-60b3a7427bad" },
            { name: "Italy", img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZOXnLXx-JGdssNPvltFbsfUFehd98M2gK_Q&s" },
            { name: "Dubai", img: "https://images.unsplash.com/photo-1528702748617-c64d49f918af" },
            { name: "Peru", img: "https://www.alpacaexpeditions.com/wp-content/webp-express/webp-images/uploads/Machu-Picchu-CuscoPeru-best-things-to-do-in-machu-picchu-1000x666-1.jpg.webp" },
            { name: "India", img: "https://images.unsplash.com/photo-1548013146-72479768bada" },
            { name: "Australia", img: "https://cdn-imgix.headout.com/tour/20072/TOUR-IMAGE/d85280d5-3c4f-4f54-bd7a-6fc5cc68597f-10732-sydney-sydney-and-bondi-tour-with-sydney-opera-house-tour-01.jpg?auto=format&w=1051.2&h=540&q=90&fit=fit" },
            { name: "Japan", img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUTExMWFhUXFRcYFxYYGBgWFxoVFRcWFxYXGBkYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGy8mHyUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAKMBNAMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAADBAIFBgABB//EAEMQAAIBAwMCBAMFBQYFAgcAAAECEQADIQQSMQVBEyJRYQYycSNCgZGhFFKxwfAVM2LR4fEHU3KSokOCY4OjssLT4v/EABkBAAMBAQEAAAAAAAAAAAAAAAECAwAEBf/EAC0RAAICAQMEAAQFBQAAAAAAAAABAhEDEiExBBNBUSJCYXEUMlKB8BUjkaHh/9oADAMBAAIRAxEAPwDZBhR0u+tV4api7XXpLamhx73YihhvSgg1JaOlA1Ox+zc9anczS9kU6iYrmmkmdEXaFAIqQWmWt14LdLYRC8k8UNVpxlFeoop1KkLW4O2leutEuYoKtJqfO49kSagtujspFck0rCg+nT1o9wgCgok+1ePeUc1ztWytkW1FK6jVE4qN/Xr2FVWqvM3fFXx4b5RGeRIW6hfjvNKWbz049pSKCK74pKNHFNycrsIp7mg3CTXrXPSoEmgjNniqO9cX9Kg1Q2mqJXyScq2QDWXTtJnsapui3SWuyceI8e3B/nVzqbflJicHHr7VU9Cy1zyFRuZpJBncQOJ9h2x+NBtKSF+JplsBRLdqaPa0802ujMU7yJAWKT5K5lipK8UwdOO5r0Kooa0NoYG0jMasrJVBzNLK4HFFAJ71DJI6Mca4C3deYgCKCGYmpraX60whngVHVW0UW0vyyADD2oNz3JNMvfUcmlH1JPGKGmt2HUnsjxbpHCxXoDtzUrNsmrXT2faoyyKPCKKF+RG3pDHNdVyFb2Fe0v4iQ3ZiItYqHh00gogt13KZBwElmj2xTAsCprZrPIL2z20lNg4oKCKITNc822VSSJG5Ud1QKGvRbNLdDVYO5bmuWyRTS26mLdK8vgbQIsk1BVIPFWa2Kk1sUncNSEGWvFUfSu1XtSLs0800YuRm0hm9eA70hqL81O4Z7Goi37VWMNO7Jud7IQZY7VJVmnig9q8ZIzT93ahO2J3LcUq1umdRqKEhmtFugNID4VSGnmrSxphEmnrOgByaV50hlhsoE0JNT/YorQsicClXUCl/ENh7EUZrqdiLbkwAEaZmIg8xmPpWc+ElVrlyAnBjb5j8wjdc7/X72T2FbLqzjY4BM7WjaQDMHgnAPuayfwncK3HIW7wfna1EyvCIAZ9uFxHzVnKTFaimjc6SxIkCBRGCiq+3rniI7/6/zqS72NKl7ZS/SBapZ9qUFuKtRpR3Yfxodywv734V0LJFKkczxybtlO7Gpo1WI0img3LRBwMUG73YyXhELds8mjx7/lS5vEc16da3YUjyLwhlB+WGFocmuMdqAqXHNW+g6d3OahkyxjvJloQfEUC0longH+VW+n03rR7OminLdkdzXBPqHJ/CW2iCW2K6nAqe9dS3ITuIzS2zTFqhjdXSRzXtO2T4GqG1QW570U5FCmjWiAPvRbQoarTNlKEjKhm2tTxUNtehK59I9okDUwa821AtW02BsmWpW9qgKk90ClrrT2qkcaXJNyfgg2omkjdz6UdrR9aAbFVjOKA4SYO5qhQzqxXX7XvSbHNNepCr4Q/j1C5dPrXIs9qILAqbcEPUmIuJNM6bTkmjpYHamEG3J/KlyZVVIMMe+4/pLIAk0vqtfmBS/iXHx29BijHTADMfT1rj1JO5HTpb4Er+rPaged6cuWoyOKEtk+tP34pbCrA3yIdT06rZuFtkbGneTsiDO6M7fWKzXwZbQ3mAOn3bWgIS7EDaZ3nMc54bHpW1vafytwDtMEgFR7kHkVl/g/UsLl4s6AFt6qpBkGR+6BGVwPQehpO7KcW0aWKMZRNK2nbd7H+X+/6VE2W7R+Jr29rCYzI/l3/QmgXr5PCz9ATWi2+R5JeDwCOWn6AmpqV7A0PxrsfJH1xUGLHk/lV7Od/YOxP7wFR/Zd33ia9sKvcU74wHED+vWpTyPhFIwXLF06TNOWOnW19zQhc3Hkn2p6wh+lQyTl7KxjH0SS2BwtHRG+lERfcU7Z29z+Vc2m3uaeTSJLaPcmmbNs+lPoEoyFew/SuiOE5p536F0tmK8p3f7Guq3ZOfuP0ZC+XpN2PetCbFAuaMHtV4Z9PKOuUVLyUgFEDGnbujIoXh10rPFkXgfghbvRzTH7cKXdTSjtFUWmROWqJajW0ezqSe1Ua3qNa1TA0s4bbGhO3uXouTUmNIWtaDzimlcHvXFJyR1qKYC7HpQg2aPfsTxNKtZIrd3Yyxok7egoFxXPGKZQAUUXRU3lopoKw6FifMakLSL9aeuEH3oA0vtSvM3yFY0uBf9l3cGamuiPemkU9zFGXb9aR5vRtKAW7QHNT8NPSa8vXQO1IXdc/pFInJjNIdf0EKKWuADJalWvk9vxNVPU+uJaxIuP2QGQP+qMD6c8fWhpfkeL8Ia69rttvZaBNy4dqAfN/iI+g79iRWP0vxxqLRNvUJLKSCYhpGOBA/ExVR1H4lueL4ivNwEEMIKrzhQcd4iPvHvMrXSdS4Lbzcc+Y28lmJOCp5PfB71SMYRW6Lx6eUuXX2NfqviPS6lVDXikSdpDQTggtI2mI4JIzSv9m6O58ur085OVUmTzhW/qao+odDv2btq06Wy1xCwFy2ikBcZ2SJ8v8AnQL/AEl0AZ7VmJ+690Tycxx+AHFdWPLFKlE48vRKTvufz9j6bpL+xFQGxcIEb1cKSBgeVgYwB3/jRf2hoyj/AIMrf/kK+TWNAzeVUUnJMXHHl8uBuEDvn39qNf0N6VXw4J+SbogBQdwAJ5+X8uPTaoegfhZ+Jpn0031/dvD/ANoP8GNR/abcf3d38UP8q+bXuk3wTFq5n5ALqk88sAN3HeAOaF+w35IlxgQTdBUMI3bmXyxhsTPFBvGwLp8q8o+kP1O2uCr/AE2RQ2+IdOuCGJ7KAC35BprFWvhzUkEsCoJRQblwrLvtAIlfMCTgD15xB0PQ/hTV2mBV7aTAZgu5o77SyeU/jSTeOtkNHFK95o22luEgQkY9pH5U0tljzNNaeAKZS4PauevoJKbQKxpRGZ/Gm7dhR6V4jCcimgqxgZ96aMbdEJ5GRtso9/4UdXpF1u9gF+kfzqC6N2+Zv1n9K6o40uWcspN+B5tbbHLD+vpXUNNAgH+1dT/CJuVqav1FHW6p70id/wBaGd3+4qTw+j0vhZaFaHcsgjikF1LDt+Ro9vW/WpvHNGr0xbU6L0pBtJBzV7+0Kag1pTVIZZR5M4p8lKNOe1eiwe4q1/ZakbPqaus6ol2t9iuWB2rvG9KefTL9aD4H0FSc1IrGLRyanGZ/Kjo4oDkqJMAepwPzNLabqNu421XDRyRJUD3YCKTsOXAzyRXI8yT6VJNODUA1tACWBDTDcr5QWMkYGByTQLvXbSuFG5sEttHaDmOe2BHeqQ6X2Sn1P6R+1pcwDQ7ispg0t/ai7vIRxkGcMxUgEY5G4CMyKrtT1fUo7I9okboDAFk2bZVtx74OOZBntJn0ifGxOPUNP4ty1ZxURbJ4pGz1lT8ybcxK+YTPB7jt7VYgyJBBHtmuHJhnDlHXDNGXBBtP6maCwUdqMG9/5VG5c9AT+UVHcqmYf4o0eoe8fBt3iNok7k8OYxt3ZU+sRVKPhPV3VBhFVgCArBpBEhiQYI/Gvply77A+0zQUdu8x6AQKfU2Ujk0flR89sfAbffW6302AbRySASxPooM/wq11GoOmtWUs6dbLS7qzQ1x2teU7okD+8AyasPif4gfSEEwEwd2WaCYMDgxBPft6iqTSX01QVheW84kkKwtlS4G7n7RTMn7sTTrFOSA+rVruPb0I/FrWbmqsxevXR4b7nYOh3DsoCiB7Ad6QfTWR/wCpfE//ABLg/jVtreguz7jat/e/5gPmORIfI9u3AgVC50ER/djHA8/pHM+5rpWGSWxFdVhklbK1NEp4v6gf/MP8xTfS+mh79oDUv8twhmYMBBWe3ufyoFzpbAkix+oP6EGvbPTbqwVtMIBAggYMHJ25/wBx61njkOuow1szY2+laaNpu7jmVV4kwPmzJggxOMwQcVZ6bwUPltqDmDEkTggHMDAwIrJfDdq7buh3tsyqhUQbZiczlQe8YI5/CtKursnlLo+qT/8AaTUnCSfBB5Ivhl1avWyACBzOYiRxyKZVJ4YfnNUVvVab9+Prbf8AjtppNbp/+eB9AQf0FTcpJ8C0n5LZbZ9j7U1aAHKD86pun9R0ruVS5vKrJMEwSYAPpwY9YPpS/WdPe8zK7G2RjbGCIKmJmJ9Jiak5tvg1R4sbf4rRLzWmULCkq3Yxx2zPt6Vd2rzuAdxggHA9a+cdbKNp1dSWdZxww3LEY4BYg84P1rR9L67vdSWi2NxEkxtwFn/UdiPraOSa4RCUYezWWrX1P1o8N6x9KrU6kDw68xiPp/Kpm8T3J/GrKa8si7G3C92M/jXUlurqbuIFMrv26znzxBg84YzAJGJwf6Io+nuo4lWn/THcTHvXzROrXCxYurlVGWJMq5YfMcgdoGRB9QaLpOuXi5dWjCiYEKMwIIIHynn0rq02dFteT6UbftSpa1JXcsiZGJEEAz6cj86xH9tXGYhdRcDntsIBiCRFsGGB5gRkDOZSvLfM77hYExKuxAWSQSFAMfNMx9OaVQsbU0fQvs923ck+kif41125aT5riL9XA/ia+YaslcsZUjBmRHuf65pFupWgOQfoJ/0qy6VNXqJvqXHaj6fqPiLSpzfDeyS/6qI/WkbnxraHy27jfXao/ME188Tq9r/EPwP8qInVLZ4/Wf5mnXS4lySl1M2bO/8AG7fcsAf9TE/oAKrNR8Uax+HCD0VR/Eyf1qjOuXvXHWp/vVI4sUeESlknL5gmod3M3HZz6sxP8TNehmiJheSqzBI43D70e/qagNan9RUhr7f1/Cra4k6vyem/cxDER6Y+gEcDAx7Cg296tuBIbndMH86MdZb9a4a+36/w/lW1xFcX7Cftd0OLgY75DbjB8370GRNQuX7jAKzMVGAs+UAcBV4Uewr1tWn9T/lmvU1dr1P9fjR1xA1L2eaa3Bxgx2x/X+tPWNXdT5bhH4yP1pYa20fX8v8AWirrLPqfyFByg+QrUi203XNQv393/UAT+fP60wOuXGgFF94n/WKpV1aev9fhRrWrX1Fc2Tp8E+Yl4dRkjwyT/EwBIICkHjz3PyKgD9aR1XxgRIWAY+8Qv0hUO/8A8qp/idbCNbCW1BJltsAlZyCORwIM/ePpR9N1kJsKhNo3mBbCeYD1PljmFkn2E58qeGMZaT0PxUKvd/6IW9f41wtfs3rwKsoYJsVWMbdokT96Zn8c0ja+AdS9wBDaEswy5O1lUMwO0GDDCnND1hyTvt7lhhG0woIMhSRByVIGOMzgVpuqsqam2i3LjIUVy24mGZyr5HHlA4zUZzlDg7ME1mWmMa+6vwZTqXQNRptQun/a7o3W98q7wADBESJyDHFeDTa1RjW3J9xP6lqf+MrOkbW21WGt+C0+cnzByOd0zVVc0GjH3R6fO3Pp81XhOdbsnLHj2+FB3XX5A1rR28iic98YrlOuAA/bIJYDcVH3oUKRtiAWOfrQF6Zpf+X/AOT/AOde3um6YLKrJV1nLmCWSQc+hH502uXsVYYP5UNG91NGgaz6wB2McbMjj86ZtP1dseK5z2tKcAgEj7OOZ/L3rcDrq2kBO0LhV8rT6AQCZOBXrfFODCTHPKiPXOYpGuo8V/klrwr5TJWel9YaPMRkjK2liI/w9/yod/4Y6ldLAvug7Wi4i5gNBVTHBH51e6r4rvLkqyiTkbGXH1WZyMGKFq/iVWtu1u4Vdpwu23uYCCSckMZXMmYgDmpS76+ZAWfGntFD3SdDfs2WS5prSqICi1k5nczktJOF4z+lRs9RRWNq/cLSxCRlgZAjy+UiSRJ425nkZC/8Z6h2A3PbyCeTwcRnGQI/H3pexqm3eLccAlvM5ksR6LklT5eRH1PFJHC/mEnmUt0jc29EktbaTbYK6sD5wreWSvJiPx3AR6g0mmLW7ina0xjPzMDkGcySSM8EGqTpfUk+WyNh2gbngklAR8055JgRwKjb61eVfKUAIacA+a220z6EBV95qjwTrZoVOLZbdIu3fDZieLeBkQ22SB3ydwmK03TeoLbQLccAjmSognnkyY/mKwl67fAEvClJCjy4JJ7ZjAMk53fjQEtx6cevtPNNHo5y5dAeSK4Po567Z/5k/QMf1Arq+dhfWBXVX+nL9TF7y9BBo3tXRtW2/iKSYcbfIygRvkbhvye4YehAJfv3g4t7NpO0BBtKpyX5AGQVXP74wYIprxLVxl2geKvlO0LkMZXcd2TKMYDH9aLYsuE3qruLrBp8qMAASCSWBiPNuGCSe5munVY9VwJ6mze2YZLTThiSCROVaVBbkZ9ZnIzXXel39+43lJbuVBmTEkSQeATM/jM1obgQAlnf183mJAPzLPcZwpgRMZkxGqcEhHbPDbTtwCWB82RAOPY+9NaQji2wev6QblmL0MbYY71EMBndj7ynaPpniqxPhNdoZiRuGJ2Dgwfmg8RgiZq2t9RuAwH2LJgmGO/7w+acEmCYJk4gVHVdSubyS4/7R8szuIaNqxHP862tpbBeNS5KxvhITAZcDMkMQ3JG1BxyOckRihL0bTiSfGMiZAVUHf78SPlGD3rQ2dOm1WubCsRMuqkCQANgIiBxOIFGNqwxZgwtiInawhlBAJng5nvIAxiaPcYnZXoyOo6KxLKikCJJZxIAz6bTwcZjFAtfD7wwuM4hZj7MGBO5iO4GBPqI71q00BIBt6lWEsCQAMAHE7pIkn1GeORTug6fZwGJutAJZWcAYHLbo7e3NN3Ddr6GJ0Xw/ZZm3apgo2kEIWPmkQ3GQciORP1Npa+E7ZkK10ywCNAHYzhvTHBPH56a90y24MKrr/hG3cSAQA6tjBnsOOImvbOgth9qgJBIaVYE7Ru2hgYiT3gfMBOaHcCsCMDrOn+C5t/Zu5GN10DaMGdqnuDgbjxxmiWunlydzogEQEJIHJg8gn3JPf0rQH4Q0oaWXeSwO9iSTBnHn80yMgD/ACaPQLCgbACobzFtgaQpkRtJIxxtrawdllDZ6IhOQzCSPnMdjJGGj1MYqKaG0IbZMxiN6A5nJYZPaSOPxrXWdDpSu1i6oB51Nm5u3HAJuiBnE4jA71TdUt2t2w21Clhs80SqdzABEzMFeZGa2oGlcFYvTrZYsUfnA2KgCiOw3HiT3n601p+k2rkkIQAchTAA5JkDEVZjpiFWcCAQEg7lkyQAodwWbMiZGJ+jSdFi2wUquyHJPlGOcIAC0oJ4759UeVIOhMqNJ8O2XxvYQYMOMNMFYExBjkHkHia8u9M09pDdNxyACcNu4E7SVXk4wP8AWrnRHxbQutcFti4wxVZU91VlIXAgQRuk8zNZr4h6vZVAbV2fNGxis7rfzGBjbLckjvHeg8yrk0cabozGsW7feUt3Y9CrMATho3AYAxMAmAYq10Pwtq7qqvhqomTu2jmMYz2PYirPp3xxZQDxLKg/WMCfukMJMHE1o7XxxpTEh1nHCkHiY82a5ZyXJVYb/wCGbvfDY06qt1C7MJ3W3IHBEZH0/P6AFdkw7i6CJibrTzuIAAzk13xJ8Y3QQ9izNlcMGwxJjIYSFiOIOM0hp/jbSP8A3iOh7llLfkyST+IFaGKM92y8+ozYo0kym1thHcMVu4BUZt8Fi0nyAA57RHaoX9HbAB23CMGfJGPXyVph17px/wDWX8dw/iteN1Ppp5vp+f8A/NdPbXs411WT0zMgWpnY3p92Py21NdPbIIgw0k4HOO4GOBxV/wD2h0xeLqn8T7e1eH4g0K5DSoIEy8ZkxhfQGpySRWGfLLgrOnaFiV2oIVg0TksnGSDHHNXGs0jv8qOrDI2tHbuJA/OcD8KnpPi/p6mSf0uGf/p1dW/jvp07ZJx2S4TweB4eRWTTVAnGb5Mjpej6g3CWkbgOV2qWB+/GByfN6nPqG9f8E3dq3UKlmA3W1IZxcOJhMEZmAfoK0V34+0GCFcgmAVtGGPoCYk+1Vev+P9Hx4F/mMogz6QzzOfTvRWOHliaZcKJU2Oh3bLIb9tlBMboUNBPm5mMA9px6irXT9O0rbjb0918QpuuUExghVSBkHmTnjgVS63423Hw7dnb5oLXDO2DBJRcmPTdTnTr1y7cC22OoiCsoFCgbg4RGB2rLTJmJ9qElBcOx1jyVbjSFtd0VkuhQCQ2VFqXNskShMAEAQfNHAHBq2awwTfdWI3G4oEDcRZG2DBUMbbHj757jFno7t5VJZwFI/vHVLr5JEptghSc5AmJinVvi5bYXXZ0AIV1RlxB2gMVmSWgAgyyiM8ijaTJ2NUCWYsN/p9eBA4AxjiBHevdNZe6YWO/JjjiPepW1tm6bYW4irl3ZinHI2ydsxySOOBxVxpLeluEbbi7lBLggGUUeq4J8uc9xirQn9SelPkrrfSH73U545j2ma6rRunWiSfEXkgygJxgAzGYAEV1N3JB7URTq+nD31shgXe23Ci2ZYyXwwbA8QATORmnb7WWQMpUggCCWVWgiRCx2Uj5ScnGKj/YguMbyg27pVASHOyR9o2APKoDATIyBwPmS0vTbim4twNwxElSftCRAY2wApxlSfUweJ+bKVWw9Z1VxSb500JgEsoeDIEE/McAiTjA4EipvrgbhDswDjdsuyAzSTu3GYxnntwKqLfTrTIxHis0BAPEZsNO0gcgQrANx3HBNNW/hXbYFlWjnaIAdo4wCSBzI3SZ9qLfoVcjljVtA2GymMBg7R8x3gz5SckCJifWgsL+5nJtlVUktZgtMY+UbhIJz+lL27dtd1tpuXEkXFQs7AsTyWjghux+XHcVKy1rdttDxnJB2mUaEJIVyRI2icse/GSKVsfUQ1nWZVttpghCb5nw/DuEHAYgK488T6TjmhaO7fBR1QpbzL3Ja7MfuggsxJkZPz/QFu9oiB4d25ZRiu3wgEeAVJ2W+NgPJ+s55Ntpb3iKGS4AIiXbJZpCgmSGyCOJ+XAnBQNykPVTuIN4mJjeoQzndtJPy4GD+MSRVrauWysKZaJUOAqypCqFnAM7AOCIqqXpd1tzOqllErbTaIUypecAswIGeA0DkzYaXTABVWWWYO4giRuXEGEBEgehjPFYfcHZvXGlfFMlQsSVPEEwf+oGf8PYVYaldo8wuuQqidwBIxgBiAc7sMeJziKS6lee0VZZuzABOHYAGTiTIiMTwMAV41wyVNsC0rsAXYbS0TPmbJgkDkzzWMT6TfN5C7NJU7Vnw4ABzCRkwBwM9jxDus6pbt3ZlSzAglmyDnsxgfewY49qz2u1y21W0uze7MQqtKgCdzAgAHbx5jAJEVLSwFS2cvyxEXQY80S0m4DIAwsDEZmsay6PVFuXflRriAncxSYwMGcpkmIkfWjXL9i+5DWVOCpJ+TcymZiZUcY/f4yCQWiQyqSVt5K7FPnhiZMk7dgA/H6QB6m8viecW7hBkMTtKo2BmN0sykQSeMDmtZqHreuSx5fDZUgYUFljA2+YTMQAB60ZdfbuhsGdpG5ixSWEqGjK5jkZiMzVcyk2oRy11icOYUMZaIA3FRHfmD7Cl7um1VncLYBSAVBuedV27ZIgzmIAXP14UDVC/xFpGNttKxLG4CyXisKWUg4QsdoiJKxyeTWf1Hwreu6cQ6CD5jLBRJLeWF2rkZ45yBWl61pWu6bc3j23RWg+dmhigIYIQGaNhAg5LelUnRHuFjcDGcAqZG3MhgoPfBzPyj0NaKTYkkvR4nQdKCPEtEgyxVbwbdkKB88kkLMR97vxWltaZrWlC2m2W0VgiMyDcUMyWbduXEEAT5hwM0K30Y3RLBGDKFMIoEDjgSe2DgQIAprUdNDLF07gDIBAMGSwIkTg55xFaUlE0FfBltBc3HwbqL+z3T4rHc283GUvMyVRSRwOxx7e/CPTNObwt3LCqdz7plhKoW8rnzMAQM+1C6pqCjneouIGBUtIfvkuILGDGcZ4pfR3bT5Rmttx55IJgx9rbAYn6gAetck05cno4s0EnHjb+MF8Q9Ot/t92wMWgisACJ3AL97kcn649Kh/ZdmWJ5YQeII9YAjd/i5nPOaqdY117xu+IslQsl3YmFUTIUyMUHULc25vIPf7X/APVVYwaSQk8kW+S+XptgFSJ8uFO48eh/eHsZrrXSLG0KAYDBh5mwciQZxyazjMTH21v/ALGOPxtijJZHzbgSAeLfrHYsvpTOD9iLLE23wd+z2/2u7cHF0DDMCVKCQOBGSTkcCrzq3xRp9M1lUtggM20JakSx2goIEsfMMHuOZE/NdFfCFiA5JYN/dIACAQIi7P8AtWl6FrCbd3dc2tcZnCsGRJ2Qok792Qvcd55FMrJ5XHmLHOq/E8qf2cK03W3MwXyPtQgbQBDGLgkiTsn0NVVnrmo2MzPbCurfODGWKlvNkZg7RzGcQTpQ7lGOnNpftPlsKqo/mUEmAWDFQPMSOBOBWJ6l0t31LuGa6hYqdoLKMkwCBAAUSPYA8Uktnuc7cluGtdWQ7EkOGUgs4UZjyMMQoJnHAzzNWfSdZa2stoydjESFBWASVTJ5gkfT3JrKnRKt1QDORxztGTIJIPHaPpT69I1BtBramWZQCIXAkLBHZWJk+/41lTMpyoe6l1285KvdaDEJJAPED93tge3rR+k9aZdRDNCsQh3GYDeSRBBAEg4/d+kJa6ywbcHlCwFzyHb4wyzBWIhWgkH1ByMxUXtQN8SEcAAyItEAACQxJUxAyYO0ZXvqFbdm565f3B/HuOrqxCElXV0BHmKqognvJ5QZrL29aLQ+z3M54LwqqeQyKpO1lk/exJ9cXPVLW8W77Kyzp2DqYLb0Y+IfMcZBj/21XaW3J2iyzPOSzKVMEA5gAEkLB947ihLZ2Zip6zqyWO8ZY8IgHpgESBiurYWPh/Qsoi1cxjAwe8ieBmup6+ovbl7JWb7bQEKlEEeZiCAFA8ptoxaAzQZJEtng1IXtaHebbG2WdW2I+0eYEsQvmeZGc4b8K96Do2Z/trVsDYu1rAkmW4KgbpUAEyASTzxNvc6SApKEL2ZvEYkXMDE7okhYJ/d5FVOh7iGq0Je4GuCAokeZiHyNxZBkmWIxA81Q1PUgrAbFt7lkMGB3ENbIxEAHcefxI5pv9lulQvipcJbFwyqlV37oAbawBjuPmJx3Ha1F2662zYZQBvO7bcA29vKxUnCx6T2NENJB9XpVut5nO7aQSsgwS3mywkEy0gAHJJ9F3vaa14ZdiGZW8jDbeYDEAWyMDHYTOO9GtW9VudW8NWChgS5CsV3Asq7QcYyT+gAKOmv3bt7bc07KylodrQO0LIPnnJJSPJjzAyQwNKbYteldHYrGnEQxO9gPEAYkEbYGxo7Yz7Uql9rbuuydvlUcbhtWTCwFXA/14BLS3BK27+x7m4lramDMkAqWgGAxgEYBM8mq270wrILB5DQSDuMMm7cGcBRPh4EEkHHrOOvVvwLvYvrdSUUtsZisyA6MsMBuUKpkDHPHOZE0ZerXSPInh23Viu6RjB3DaJVctHGRxVPr7V61t87Ks5EEhNoDFbgcMV+U8CRJmSRKN3qa2dyW4dQJLuSS1w+YjarAOMA5gA4k81SzORqNXYXaXuvhiSoGFAAyd4fI8v4T+eRS7duM3gvcS02ZPmO7zOQZEbfvFj+6SJpTUMtxfGvPuuEQiEs5BzBYABZ7+wIicmjdC1zbb6krsVGJ4UfJH2kDcw8vtmM5ihYrdsutA9iwAXVQZHmWXuXCWBclmG+I2kGFBz2xUNV8VLDWwquCcBgeB8ghiSo7zP0AyKptRqcXFe0q3CTtYBp3BihAyQACQI7QOMVYWulW7dpLh+1uMSEQggEkqBGZJ2sT6cYwZV2Mr4LnpGuvXTGwHd5gQFwybVYQ3fzJBnGPQgiTq48ZVJuWyCDKhSSzMBwBE7tkYiRmIql01i/bBZiODbFssCVUgAcf4gMn0HMUaz8P6m6zI0W3WCSzSQrBgvyzvMwDE/N70W/AbdDXTeuPdutDbgNyhmG4bdwBCkE5ZU3T32rTV3rt63dJAa3aCedQm0ISQJYlGNwgyD5ZBUgxVzp+jWktt4ZtXHEEM6qCgtqNoDJkQeAIPrwZsjcYuqeGigkbSQCSB95Ss49I/wDHvjUzHr8Vai2bbMqNaut52AkSu0sjKVJV+/J+ncB1HV7V3UpcR3R23BnFsm0AOPENxpcYPyx2jgA6fq2j04k3LY3MbYO1Q5YgbiAVAMMMYEmB3NKnoumjw032SwksyK0gbV2AlQTkjg5LCskwUxvonxDaclUOQSIhlDxyy7gCe/594pzVOLoIAz3U/wBZE/wqn0Hw1b3AtfDBQH2hFQ7RBzIn0Eg98GrbT2gfvLcMcAgNvaIABMRG5gScRmRmhpsyZW6r4Ya4NzH1AGPp/nJ/oYzrOlhilgkgyGfgR3VfXvn/AHH0XW6fUXlKOduYdFO4ncXhmmG2ttMATERnsoPhgKpa4ygZiPUNEkkYEA+mfYE00ca5JZJS4ij5lZ0LIMCcfl6R+lT2MuGVhIByIMeonsY5ivpIs6K3ca54otqhUiSjYJbkc7SACJ5B/InWNIl5rZLIUg7TO5hZLDbjaMAsR+c8GqNIktVbnzU2J7cdo/nTFnSniD+oreD4ctC6y718Nd0eeLkBQT7QCRJOPaaoers2n83y2SwCN4bMucrDqCrfUfSpy24KQUnzsL6LQz2/A/5VanSiIj9RP19qoE+KwgnxHjGfBYDP/UuKtLPxyACFt3XI7+CBkEAz5l/eHccilt+ijjtyOW+mHkT6Yn3/AKirLwtUU2F32nBkKSQedxcEt+M/jVEn/EgyB4FzcRgfZoeJkg3CQCM5Fc/xxfdN66Xy+r3wPUTCqcY5Bqq0+SDcvB51P4Zdyrb0DKZJNtQ7eslCq9/3Z+tRs9Ov23Lo+0eiuSAIVZKkQSAvaPqJM1mr+L9X4ZueHZtgESDvuGGg7pUgDBJjnFU+v6nrTcKXLg2jzEJ5FKj/ABYaMHvT/wBlLyCEMrlSa/c1Gm6rfW9N+6hMTtIDrbZcq580wJGYGIPIBqk66d18ksEAAlFVBtZgDBbbLLBX5vUxFVd224g2/InzbQw+bkkEDdHH+Zq5Gr8VV8RR4gwxM+cfdKuQIyTIJgkyPfmv0Wkmm4vlFnpdPduafTLJJtOxAVl8y+abUsR/zFTMLDdoimLfwvqhlXsyT9x3DbTB3Dfndk4kA9+aQACaJxm2xukwwIKyLXJK+XhcY5pTpWr1e8BD4xYRt8xYjmABzET/AO0VueUGkWr/AAk8nzqcn51RW5wDL+bEZGO3auppf7UyUW/tn7quBPBmRM4zOZr2toj6DURt+r71YtYuC2/nlVJktuJlWYhhK4ABAJ7cUZLV1g5tlLaeS15rhT7MkMIZgfKQVJUGflwBikNN1BC/hlCtpGS2HCSS6iSsAAWjkEkADCjgUyl5X8W2lpgYhpBacDcMuRIBmBBlh7VQpdg+p66/ZFwk2wGYNbUzDsTbKtJyBJBAWNu1iRXrXrlopvv7kdmLMqth2+fckjPmf6Q3fFK3OspeTwns+IZJcINqF22LlyPsmEsfUSuDyZN0QXPPqE8zK24BlVQwLrbUIVliSV+0YEn2mtuD7ANX1hlMI4ujYU3KjOwSTCsyyi4M7eIIGIzV3/ipneDtVQgU79zEbDKEbcqfz59BV71DR6dlWQ9pAxQOoRN3mCrBK99wMw0Bh6mKlug6cXWZb3hjYPs4N3btILRBDskBTIBw0yOKVsHxWT1PxnbG1bR2NJVCwOwK0b2Y7p5IPm7TjsXrfVNVbL3WdLiqrC2CQQyqsEyTIBMeYfTg1nr3QR+0FkbwrWQipPiXcAXBaU4CeYZ+UjaeKBc0OtVLdo2L2wuCbYB2ySVcbhCbSAcHEDOC0lbqxXJpsNrda19rhKOlkEEAt5lVjICs3yWzg9sHBAiltNpJI2DZbDoG8pucttDeQDcJxEwYMVrtN0m6ilAqwzecllcNgBlYbpDg4AIO09jTnTunbSB4/iPbUkrbAt2QojkfMwmcgz5ccg0KsKjuY601k3n3XHFtSWUgEMH8oLEESsABc8RnsKa6l0nU7zct2zDgTcMAMpgo7TwZQMYEwBMcnZ9RZ7d22BZF197AuLR8rRLSRuFloPJGVzJAkD1Wp1EOAhuvIxaYfLDAGW2qAcAqCxnjma1DUipu/Clt2Rr98m6kCQ6uqhclCmPKpacgHmdo5fPwuGuqwZ0tC2qlFcBhDLsWWYgTCz67D7E0+k6q5ZpN1eVJe24ZUBUMC2wbSYaZIJ2jIIBFrpOpI1vxVuWWeAdodcYDuoO47p4x3iZgUQbPcO2lsxtI8MESxcMyqpYgE8bS3bcBMfWZ2U0mlUeGvKLsuSGa4NxwhIJMT7ATyBk1f9uz5Gts1w7VUTC7eAGZMENGeVhDExlbU9KK2VvvdYM0BtzokliAiEp8oEyQIIG6CAIrUkFy9Dl+xduBris9tCxYBkBQEKudsfOYOCOduRybDpy6sMs3FYq58hy0gQCSBkSFMniIOQKS0esuLFqbV75ZDuHKMsNcYkxIlQwBg+uIgF29ctLfDXlB3uqyDaLNuHmtATkA7IzM88AmzWXOmR3Rjfuecs3lIKkTLrb2zMxlhiYMTBJs9GNNaBHhgEL5WAIktHlViCRjjGIJ96wGj6y1zcbjai2ptjzhTbLeYt4kwAXMWwBMAA+gqzXW2LaKGuXXUTv+zvIgBEkhjhjMenHE1gWmjX/sCMWLMQZBlgW4kwhGeRAjIA44NK2Ph+0bZs3LjP8AaBgd0bBMItvcoO4KQc+pxEVQLqLDKHe9cADB4UXSu2PKBcA3CByJAMekik9Tc2NtcXwQoK/KF2lxvO4kK52gAYEwBHpgWjS67p237O0ssUUeIzNJAIO07p8x9FU8SSJApG9b1undFFs3ECiDtIDbigFss7einPEESBJk2m+INxhbeFU7tpRrh8OMeSREsQJ5k5zNS1wS5vIvqRsZQoDR5S87kJxJaCAJkDk/KBkzN9a649u5ufSHxIku771NsN5dptnygusgYzJ8xOK7Vf8AENtw3WbZ2M0De5AJDL5Sc9wMzhcRNXSFrKtZfqCAEBrcKmwryQwILTiBB7gjEVn+q9LtqhdNZba75mfdbRFdoDHwnVYYzIyckjjNEDlSDWf+Jl138y2rQ3Ft62vFYYMDbvWTJPmmRj0qei/4iahlCvpluZWNobau0k/KVYQN2IiNoyaxN7U6g8XHH0cifoAc0Am6xy7HjBYn34JpiXcNf1vqNi7ZVLWk1NpkgLgbWC7CGusVBLfOJ9ge8D271M3ClskGWQEl7RcnxAWLy43HbIEq3tnIzdrpuY9yOBx/Rq50nTR3AP19vY9s0jSKLK6Hus9I2KpCPO0SEDMAwXMjjJmDmh9K6oluzctsxBKqqyMShYmYMRmMx2qw0+pu2xt3eUYCN5hHYD92PaO1E1d4XAN8rxEcY/X8jS06oDcW7MfYYgPbJOVIg8buCD39fXinupOWfxBEfeJwNxJYQTx279qbu/DT3fLafcTMAHzczhTB5M8/xoZ6JesGbyuoiZa2dvl94Kn6E03AulndRdBCgBuSWVjjaBjPPPt/CiLq7PPhqIX7wYRPfyHP4+n1qB028bgoPlMQNhkkHIUQOOw7n2iuv6G5kkzMZyM++JpU4MLUkbPV6e2/TkYcs6+LBx5CwnuIEjP0pbpGifTsL3gtcTaShfzKP8XlMYg4P+UJ2NUw0bKw2k3TALDhRb4B5IImO3NI/tzqhVbj8DykyPM8cHEcZ7etJpkuPZdShzJeDS3Ova4k7b2wdlVVAA/I11UaPuALISfoBj8Qa6qamT2Lr4P1dx9IbrO3iRs3AlTtLAEeWI+vM55zVzr/ALU20uEsvgboJJlhbXJPJ+dufWurqYaHA/Ygae3CrlnX5V+ULdO0YwJtpxzFN29MlsXWRQrRbII5HiQXC/ug5wMZNdXUWZjGuQJqAi+VeIHp4W+B6eaDj0HoKVvORdtqOPCQE/eI8fZBb5iI9/1ryuoMxlPhKyLupe68lxbtgHcywGuX0IUKQAIVcARiea0d+2Fe4RIPgXTyfmQbVP1AETXV1BggWXRdFb2AbQQS2DkeRre0we4k55zXt+0C4x8rogjy+RmfcMeuxfyrq6iuAP8AOZyzqm8EtInayTA+UqTBEQcqpz6Vpem6ZWSG3GQPvNPlTEGZH4V1dSspMoNY5VyoJgBIkk8sqnJzwf51KxpLbXbyMoKgnnJyoYyeTknn1rq6gB8GYtdPtQzeGs/s9q5MZ3uW3n8fTjigdPusdS1lmLW9qHaxLDO/ndJI9uK9rqZE3yPfEKCyLl20AjoLRUgfLPiKYHAEACPr6msrb191FS6HO84JMNjZdwA0gDyLgDtXV1ZCTNF0jqd5rBLXGYkEmTOd9wTn2oXxVqGL2lJwZ9vmUzkZHyj8q9rqEeRn+QtNDpke0jMJKs+0yZEMcjOD717qrYN3wmlkABAYls+buTPYfkK6uoskVWtsqqOyiGCtBEiIA9O3tVFrs3GJyf2e6+c+cQQ0cTOa6uoIfwa/U6K3aurbRFCMbkggMYVXgAtJUDYuAf4mpaPWvcv3rVwh0t232BlVo2wVyRJ+Y8n09BXldTeRlwWHVel2DpNYDaT7JGe3CgFXKFyQRnntxGOMV80toImO9dXUWTkP2hk/U1badRtmO38q6upAeA4/n/GuYZj2rq6mQp5cUTEf0KttD1S9bwlxoEwCd4x7NIryuq0eCVuzWWuj6fUWle7aQuwMsFCN/wByQa+XdXG3UvaE7FiASSeB3Oe5711dUciVHahPp43Nkt3MbmAn6A15qV823tk8nnBmva6ox/OP4f2GzbEA5EgEwSBJ5MAxXV1dTMQ//9k=" },
          ].map((item, index) => (
            <div
              key={index}
              className="relative rounded-xl overflow-hidden shadow"
            >
              <img
                src={item.img}
                className="h-40 w-full object-cover"
                alt={item.name}
              />
              <span className="absolute bottom-2 left-2 bg-orange-500 text-white text-xs px-2 py-1 rounded">
                {item.name}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* ================= HIGHLY RATED PLACES ================= */}
      <div className="max-w-7xl mx-auto px-10 pb-20">
        <h2 className="text-lg font-semibold mb-6">Highly Rated Places</h2>

        <div className="grid md:grid-cols-4 gap-6">
          {[
            {
              name: "Taj Mahal",
              place: "India",
              rating: "4.8",
              img: "https://images.unsplash.com/photo-1564507592333-c60657eea523",
            },
            {
              name: "Colosseum",
              place: "Italy",
              rating: "4.8",
              img: "https://images.unsplash.com/photo-1552832230-c0197dd311b5",
            },
            {
              name: "Opera House",
              place: "Australia",
              rating: "4.8",
              img: "https://cdn-imgix.headout.com/tour/20072/TOUR-IMAGE/d85280d5-3c4f-4f54-bd7a-6fc5cc68597f-10732-sydney-sydney-and-bondi-tour-with-sydney-opera-house-tour-01.jpg?auto=format&w=1051.2&h=540&q=90&fit=fit",
            },
            {
              name: "Eiffel Tower",
              place: "France",
              rating: "4.8",
              img: "https://res.cloudinary.com/jerrick/image/upload/c_scale,f_jpg,q_auto/65acac9c436ba3001dbe775b.jpg",
            },
          ].map((item, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow hover:shadow-lg transition"
            >
              <img
                src={item.img}
                className="h-36 w-full object-cover rounded-t-xl"
                alt={item.name}
              />

              <div className="p-4">
                <h3 className="font-semibold">{item.name}</h3>
                <p className="text-xs text-gray-500">{item.place}</p>
                <div className="flex justify-between items-center mt-3">
                  <span className="text-orange-500 text-xs">
                    ★ {item.rating}
                  </span>
                  <button className="border border-orange-500 text-orange-500 text-xs px-3 py-1 rounded-full hover:bg-orange-500 hover:text-white transition">
                    View More
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}

export default Home;
