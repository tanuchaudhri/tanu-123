import React from "react";
import heroBg from "../assets/hero.jpg"; // mountain background

function About() {
  return (
    <div className="w-full">
      {/* ================= HERO SECTION ================= */}
      <div
        className="relative h-[85vh] bg-cover bg-center"
        style={{ backgroundImage: `url(${heroBg})` }}
      >
        <div className="absolute inset-0 bg-black/50"></div>
        

        {/* Center Content */}
        <div className="relative z-10 flex flex-col items-center justify-center h-full text-white">
          <h1 className="text-5xl font-bold mb-6">About Us</h1>

          <div className="bg-white rounded-full flex items-center px-6 py-2 w-[420px] shadow-md">
            <input
              type="text"
              placeholder="Search Your Destination"
              className="flex-1 outline-none text-black"
            />
            <span className="text-orange-500 text-xl">🔍</span>
          </div>
        </div>
      </div>

      {/* ================= ABOUT CONTENT SECTION ================= */}
      <div className="max-w-7xl mx-auto px-10 py-20 grid md:grid-cols-2 gap-12 items-center bg-white">
        {/* Left Content */}
        <div>
          <h2 className="text-4xl font-bold text-orange-500 mb-6">
            Let's Travel Together
          </h2>

          <p className="text-gray-600 mb-6 leading-relaxed">
            Our team of travel experts is passionate about exploring the world
            and helping our clients to do the same. With years of experience in
            the travel industry, we have developed strong relationships with
            suppliers and vendors around the world, allowing us to offer
            exclusive deals and insider access to some of the world's most
            incredible destinations.
          </p>

          <p className="text-gray-600 mb-8 leading-relaxed">
            At our travel agency, we believe that travel is more than just
            visiting new places – it's about experiencing new cultures,
            meeting new people, and creating memories that last a lifetime.
          </p>

          {/* Stats */}
          <div className="flex gap-14 mb-10">
            <div>
              <h3 className="text-3xl font-bold text-orange-500">10</h3>
              <p className="text-gray-600 text-sm">Years Of Experience</p>
            </div>

            <div>
              <h3 className="text-3xl font-bold text-orange-500">1k</h3>
              <p className="text-gray-600 text-sm">Successful Trips</p>
            </div>

            <div>
              <h3 className="text-3xl font-bold text-orange-500">18k</h3>
              <p className="text-gray-600 text-sm">Happy Customers</p>
            </div>
          </div>

          <button className="bg-orange-500 text-white px-8 py-3 rounded-full hover:bg-orange-600">
            Read More
          </button>
        </div>

        {/* Right Image */}
        <div className="flex justify-center">
          <img
            src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee"
            alt="Traveler"
            className="rounded-3xl w-[320px] shadow-xl"
          />
        </div>
      </div>

     
    </div>
  );
}

export default About;
