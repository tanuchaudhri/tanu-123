import React from "react";

const Header = () => {
  return (
    <header className="flex items-center justify-between border-b border-slate-200 px-10 py-4">
      <div className="flex items-center gap-10">
        <div className="flex items-center gap-3 text-slate-900">
          <span className="material-symbols-outlined text-3xl text-[var(--primary-color)]">
            memory
          </span>
          <h2 className="text-xl font-bold leading-tight tracking-tight">Tech Haven</h2>
        </div>
        <nav className="flex items-center gap-8">
          {["Featured", "New Arrivals", "Promotions", "Categories"].map((item) => (
            <a key={item} href="#" className="text-slate-600 hover:text-slate-900 text-sm font-medium">
              {item}
            </a>
          ))}
        </nav>
      </div>

      <div className="flex flex-1 justify-end gap-4 items-center">
        <div className="relative">
          <input
            type="text"
            placeholder="Search"
            className="form-input rounded-md border border-slate-300 h-10 pl-10 pr-4 text-sm focus:ring-2 focus:ring-[var(--primary-color)]"
          />
          <span className="absolute left-3 top-2.5 text-slate-400 material-symbols-outlined">search</span>
        </div>

        <button className="h-10 w-10 flex items-center justify-center border border-slate-300 rounded-md hover:bg-slate-50">
          <span className="material-symbols-outlined text-xl">favorite</span>
        </button>
        <button className="h-10 w-10 flex items-center justify-center border border-slate-300 rounded-md hover:bg-slate-50">
          <span className="material-symbols-outlined text-xl">shopping_bag</span>
        </button>

        <div
          className="bg-center bg-cover rounded-full size-10"
          style={{
            backgroundImage:
              'url("https://lh3.googleusercontent.com/aida-public/AB6AXuDktlT2QIVcUj0c-gpHJX1bJZNyeeE3OQCWGMNfdZG1FxOXGCynBAKgtuRJTIYAuLqEL3VnAEnwflFOn_LMg_Ybk3ZzqjOnP8Zm7c4IwQ-fgeFapDAnhNs_RVF0vOPPyWVgqitMnOry50cg0PwIMOOhhG6xM86fPzhlQQG-ar9ft_qklDcst2jaDHW6JZHhvhCng_hoHt-6Flyy5GK3NmpihS6eXTP57eNlduvHVgzxAy3H6jnQvd4nenG61s64ZkRVTKV8H9XBHMg")',
          }}
        ></div>
      </div>
    </header>
  );
};

export default Header;
