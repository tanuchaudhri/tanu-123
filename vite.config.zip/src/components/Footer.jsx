import React from 'react';

function Footer() {
  return (
    <footer>
      {/* ================= FOOTER ================= */}
      <div className="bg-black text-gray-300 px-10 py-12">
        <div className="grid md:grid-cols-3 gap-10 max-w-7xl mx-auto text-sm">
          <div>
            <h3 className="text-white text-lg mb-3">Join Our Travel Club Now</h3>
            <button className="bg-orange-500 text-white px-6 py-2 rounded-full">
              SUBSCRIBE NOW
            </button>
          </div>

          <div>
            <h3 className="text-white mb-3">Company</h3>
            <p>About Us</p>
            <p>Support</p>
            <p>Privacy Policy</p>
            <p>Terms & Conditions</p>
          </div>

          <div>
            <h3 className="text-white mb-3">Contact Us</h3>
            <p>+91 8795604321</p>
            <p>flyaway@gmail.com</p>

            <div className="flex gap-4 mt-3 text-orange-500">
              <span>●</span>
              <span>●</span>
              <span>●</span>
            </div>
          </div>
        </div>

        <div className="text-center text-xs text-gray-400 mt-10 border-t pt-4">
          © Flyaway. All Right Reserved
        </div>
      </div>
    </footer>
  );
}

export default Footer;
