import React from "react";
import Header from "./components/Header";
import HeroSection from "./components/HeroSection";
import FeaturedProducts from "./components/FeaturedProducts";
import NewArrivals from "./components/NewArrivals";
import Promotions from "./components/Promotions";
import Footer from "./components/Footer";

const App = () => {
  return (
    <div className="flex flex-col min-h-screen bg-white" style={{ fontFamily: 'Inter, "Noto Sans", sans-serif' }}>
      <Header />
      <main className="flex-1 px-10 py-8 mx-auto max-w-7xl">
        <HeroSection />
        <FeaturedProducts />
        <NewArrivals />
        <Promotions />
      </main>
      <Footer />
    </div>
  );
};

export default App;
