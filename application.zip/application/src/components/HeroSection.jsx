import React from "react";

const HeroSection = () => {
  return (
    <section className="mb-12">
      <div
        className="relative min-h-[480px] rounded-lg overflow-hidden bg-cover bg-center"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(0,0,0,0.5), rgba(0,0,0,0.1)), url("https://lh3.googleusercontent.com/aida-public/AB6AXuDBXrEQNjrwfVfBfeQMnsAS0_MDcp-phP1vrTu2e4lDQf90WvjczQyna0FE6iRN7HOxKpw_1MrM2gh3xu-LAcsz_nc0eKAzZKSsULhUcxXqyKbkt_iXPCu7mvuwlWUisH-fUYo1UDpW5IUN87BqxiYjP9rbVlPXUzGMv-XrCJyWEk-G-piHSHzepQ57SEFTsrZ0Y87pqBY0Ow4ltDQHtY8twQxL9M7QxcCwW9Z3uWRQZeqKSvP3rWxWzB3xaX5S2pZl6-O1GFjyjco")',
        }}
      >
        <div className="absolute inset-0 flex flex-col justify-center p-12 text-white">
          <h1 className="text-5xl font-black mb-4">Explore the Latest in Tech</h1>
          <p className="text-lg mb-6 text-slate-200">
            Discover cutting-edge electronics and gadgets that <br /> enhance your digital lifestyle.
          </p>

          {/* Left-aligned small button */}
          <div className="flex justify-start">
            <button
              className="h-9 px-4 text-sm bg-[var(--primary-color)] text-white rounded-md font-semibold 
                         transition-all duration-200 hover:bg-blue-700 hover:scale-105"
            >
              Shop Now
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
