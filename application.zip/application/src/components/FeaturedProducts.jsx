import React from "react";

const products = [
  {
    name: "UltraBook Pro",
    desc: "Experience unparalleled performance and sleek design.",
    img: "https://lh3.googleusercontent.com/aida-public/AB6AXuBDmiG-N8fiX5c0KfIk6UFx51nD1wipPYArsMdcNUqeBSTGcT6xkyUwR_u4ZdwnF7UgkZC_DkNJU_hf5KuNJi8QU-auBxIfOHukXpWbDWyz_mlYKaC-TqUOkwNhrZ524o89QUGTzsDF5XnVqmYmj3UptXgM60XOaEl8iJvfzrO7vAGgjPwg3UQ_Ld6BWY_BaZt4w6XvBcbNSjtwW2DsLgDCnZ6t332cMV0mQlX723jqiIp89UBpMN5HndH5zqotY6gWRtsASmwco2o",
  },
  {
    name: "SmartTime Watch",
    desc: "Stay connected and track your fitness with style.",
    img: "https://lh3.googleusercontent.com/aida-public/AB6AXuAnqnscB_D-Z2TyUtRK375rbAEGLHAkLrtIxjpyWNmBtNkNd8IB2uK0qpiYtUthN9lsxV8RXY5OsNYdEZEgekc1jLmEt_U3wEEw2kviRWKCSWZTmhA5zxUmMNmo3rulvFXakmeJpU_9pP2gPUfwWEdXSy9eVQSatFVrIVUHcaVAKEEIkrFFSaQAlwijAns8-2WLwGWY-xXxRXdKoM7Vbrbtbp9sXpSAnNk3NXV-I47KvPGql-V7tz041zH9PYpvAO8Li-xGsrFwXE4",
  },
  {
    name: "SoundWave Headphones",
    desc: "Immerse yourself in crystal-clear audio with noise cancellation.",
    img: "https://lh3.googleusercontent.com/aida-public/AB6AXuBL47BO9m0jBnSgXRZU2ghKRMSN0G7E8SuhdJOQnrhC6QbZn96-EXm21M8u50crNfg8fRk2wOuzqvqtjnieBDyYW-OoVgXufLVXuLj3ngJMFAxfDIbaTQMPUEp2Wv3KIREEdGHEVJo5MYgnQlaXtcSnKQzgVA7fqVun3K9yaCuLOlhZ5jwNIS1mZHSxtFKMJDojdWb7qljZOLKaLRKyhkGRurGdE-6ZipiXKXFBFd7tIHWouTKxarxtuOb75GR6tf-9CMHEBjw50I0",
  },
];

const FeaturedProducts = () => (
  <section className="mb-12">
    <h2 className="text-2xl font-bold mb-6">Featured Products</h2>
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
      {products.map((p) => (
        <div key={p.name} className="group">
          <div
            className="aspect-square rounded-lg bg-cover transition-transform group-hover:scale-105"
            style={{ backgroundImage: `url(${p.img})` }}
          ></div>
          <p className="text-lg font-semibold mt-4">{p.name}</p>
          <p className="text-slate-500 text-sm">{p.desc}</p>
        </div>
      ))}
    </div>
  </section>
);

export default FeaturedProducts;
