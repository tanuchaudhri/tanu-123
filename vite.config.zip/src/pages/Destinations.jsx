import React from "react";
import { FiSearch } from "react-icons/fi";
import { AiOutlineHeart } from "react-icons/ai";
import heroBg from "../assets/hero.jpg"; // ✅ NO SPACE, FILE MUST EXIST

function Destinations() {
  const destinations = [
    {
      name: "France",
      days: "7 Days Trip",
      price: "$1700",
      image:
        "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?q=80&w=1200",
    },
    {
      name: "England",
      days: "5 Days Trip",
      price: "$1900",
      image:
        "https://images.unsplash.com/photo-1505761671935-60b3a7427bad?q=80&w=1200",
    },
    {
      name: "Singapore",
      days: "6 Days Trip",
      price: "$1300",
      image:
        "https://ik.imagekit.io/tvlk/blog/2018/07/Marina-Bay-Sands-750x400.jpg?tr=q-70,c-at_max,w-1000,h-600",
    },
    {
      name: "Italy",
      days: "8 Days Trip",
      price: "$1800",
      image:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZOXnLXx-JGdssNPvltFbsfUFehd98M2gK_Q&s",
    },
    {
      name: "Malaysia",
      days: "5 Days Trip",
      price: "$1300",
      image:
        "https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=1200",
    },
    {
      name: "Germany",
      days: "8 Days Trip",
      price: "$1700",
      image:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRbgB7VtiWNnh3TnTbOG4hZ39tyk3KlDvQNCg&s",
    },
  ];

  return (
    <div className="w-full">
      {/* HERO */}
      <div
        className="relative h-[80vh] bg-cover bg-center"
        style={{ backgroundImage: `url(${heroBg})` }}
      >
        <div className="absolute inset-0 bg-black/40"></div>

        <div className="relative z-20 flex flex-col items-center justify-center h-full text-white text-center">
          <h1 className="text-6xl font-bold mb-8">Destinations</h1>

          <div className="bg-white w-[480px] shadow-lg flex items-center rounded-full px-6 py-3">
            <input
              type="text"
              placeholder="Search Your Destination"
              className="flex-1 text-gray-800 outline-none"
            />
            <FiSearch className="text-orange-500 text-2xl" />
          </div>
        </div>
      </div>

      {/* CARDS */}
      <div className="max-w-6xl mx-auto py-16 px-4">
        <h2 className="text-3xl font-bold mb-10">
          Most Popular Destinations
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {destinations.map((dest, index) => (
            <div
              key={index}
              className="rounded-2xl shadow-xl bg-white overflow-hidden"
            >
              <img
                src={dest.image}
                alt={dest.name}
                className="w-full h-56 object-cover"
              />

              <div className="p-5">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-xl font-semibold">{dest.name}</h3>
                  <AiOutlineHeart className="text-orange-500 text-2xl" />
                </div>

                <p className="text-gray-500 text-sm mb-4">{dest.days}</p>

                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold">{dest.price}</span>

                  <button className="border border-orange-500 text-orange-500 px-4 py-1 rounded-full hover:bg-orange-500 hover:text-white transition">
                    Book Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Destinations;
