import React from "react";

const Promotions = () => (
  <section>
    <h2 className="text-2xl font-bold mb-6">Promotions</h2>
    <div className="bg-slate-50 rounded-lg flex flex-col md:flex-row overflow-hidden">
      <div
        className="w-full md:w-1/2 aspect-video md:aspect-auto bg-center bg-cover"
        style={{
          backgroundImage:
            'url("https://lh3.googleusercontent.com/aida-public/AB6AXuBwd07OLpIYDgLVxsVZZhVyl4LiU9f1LrSKPp_ZpL4Ku5i2gLb0rAAEvn9ne0zlCbL3YEjmi8EJb4keLMiqbA2TDabeyL_rNwPp5kQgo0pf-mheTiKx4FXv-uwtylZAlWJ3O0OutL7dZFmXLy9-fUIO6cf54nz61B5RR6VUMdCkl54IryMif0-pPyKsaU1tS0-9wCGrW5w2GQxfUQrsJyt8hagPI5_dKiSOswoo6FiuGdC3FxfhfGtoEdFloh3j_x5Zgr8ZZd9waiM")',
        }}
      ></div>
      <div className="w-full md:w-1/2 p-8">
        <h3 className="text-xl font-bold mb-2">Summer Tech Sale</h3>
        <p className="text-base mb-6 text-slate-600">
          Save up to 30% on select electronics. Limited time offer.
        </p>
        <button className="h-10 px-5 bg-[var(--primary-color)] text-white rounded-md hover:bg-blue-700">
          Shop Now
        </button>
      </div>
    </div>
  </section>
);

export default Promotions;
