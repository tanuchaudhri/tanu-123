export default function Footer() {
  return (
    <footer className="border-t border-slate-200 py-6 mt-10 text-center text-slate-600 text-sm">
      <p>© 2025 Tech Haven. All rights reserved.</p>
    
    </footer>
  );
}
